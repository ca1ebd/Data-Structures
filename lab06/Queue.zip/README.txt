Name: Caleb Dudley
Partner: None
Extra info: I do not have a partner because I was not in class friday, I did not feel good