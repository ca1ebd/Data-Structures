Include names of all people who helped/collaborated as per the syllabus:
    Just me, had some suggestions from Armando Ocampo
Describe the challenges you encountered and how you surmounted them:
    I had challenges checking the condition of whether the user guessed correctly. To overcome this I was able to pull up the website and saw that you have a suggestions for how to do this, which was helpful
What did you like/dislike about the assignment?
    I liked it, but wish instructions were more explicit. Also CLion straight up has a meltdown with printing large amounts of output, very frustrating. I am also unable to test because it randomly crashes.
How long did you spend on this assignment?
    ~7 hours
A description of any novel features you added for extra credit
    Hah, maybe next time (It's Friday night)