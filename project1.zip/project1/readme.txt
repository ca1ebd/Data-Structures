README

1) Got some tips from Armando Ocampo and Nicholas Battaglino
2) I mainly ran into issues with the flip horizontal and vertical filters. I initially tried copying the vector, but that didn't work so I got the tip to maybe just go through half of the image and then swap rows, which worked! Later on I was able to figure out how to make copies.
3) I actually really liked the assignment, it was super cool and I feel that I learned a lot. It wasn't super tedious either, which is always nice. I guess the stuff at the beginning with getting MINGW setup was my least favorite.
4) ~7 hours
