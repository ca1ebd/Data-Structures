Include names of all people who helped/collaborated as per the syllabus
    None
Describe the challenges you encountered and how you surmounted them
    I encountered some challenges visualizing the tree and just developing a base understanding of how two nodes would work in the node class. I surmounted this mainly by just playing with the code and with file until I was able to develop an intuition for how everything operated.
What did you like/dislike about the assignment?
    I actually really liked how it worked, I wish that the two questions has been reordered in the Expanding the Game Tree section
How long did you spend on this assignment?
    ~3.5 hours
A description of any novel features you added for extra credit
    None, gotta grind on some other classes rn :(