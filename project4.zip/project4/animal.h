//
// Created by caleb on 12/1/18.
//

#ifndef PROJECT4_ANIMAL_H
#define PROJECT4_ANIMAL_H

#include "animal.cpp"

#endif //PROJECT4_ANIMAL_H

class animal
