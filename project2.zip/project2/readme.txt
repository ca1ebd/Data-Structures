1) Cameron Kuan helped with some troubleshooting

2)I had issues with accessing elements that didn't exist in the data structures. The debugger was very instrumental in solving these problems

3)I liked it, I do not like having instructions in both the comments and on the website, I wish it were consolidated

4)~4 hours
