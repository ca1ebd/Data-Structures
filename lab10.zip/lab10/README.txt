Caleb Dudley
Partner: Armando Ocampo Week 1
